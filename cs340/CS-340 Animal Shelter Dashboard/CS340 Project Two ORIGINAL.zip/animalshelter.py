#!/usr/bin/env python
# coding: utf-8

# In[2]:


# Import necessary libraries
from pymongo import MongoClient
from bson.objectid import ObjectId

# Define AnimalShelter class
class AnimalShelter: 
    """CRUD operations for Animal collection in MongoDB"""
    def __init__(self, USER, PASS, HOST, PORT, DB, COL):
        #Connection Variables
        USER = 'aacuser'
        PASS = 'CS340Password123'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32845
        DB = 'AAC'
        COL = 'animals'
            
        # Initialize Connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}/?authSource=admin')
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        
    # Insert new document into collection
    def create(self, data):
        # CRUD Create Method
        if data is not None:
            result = self.collection.insert_one(data) # insert document
            return True if result.inserted_id else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
    # Read document from collection
    def read(self, query):
        # CRUD Read Method
        if query is not None:
            return list(self.collection.find(query))  # List matching documents
        else:
            raise Exception("Nothing to read, because query parameter is empty")
    
    # Update data in the collection
    def update(self, query, new_values):
        #CRUD Update Method
        if query is not None and new_values is not None:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        else:
            raise Exception("Must provide parameters for new_values and query to successfully perform update")
            
    # Deletes data in the collection
    def delete(self, query):
       # CRUD Delete method. 
        if query is not None:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Query must be given to successfully perform delete")

