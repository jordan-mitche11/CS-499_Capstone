# %%
# Configure the necessary Python module imports for dashboard components
import dash_leaflet as dl
import dash
from dash import dcc
from dash import html
import plotly.express as px
from dash import dash_table
from dash.dependencies import Input, Output, State
import base64

# Configure OS routines
import os

# Configure the plotting routines
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


#### FIX ME #####
# change animal_shelter and AnimalShelter to match your CRUD Python module file name and class name
from animalshelter import AnimalShelter

###########################
# Data Manipulation / Model
###########################
# FIX ME update with your username and password and CRUD Python module name

username = ""
password = ""
host = "localhost"
port = 27017
database = "AAC"
collection = "animals"

# Connect to database via CRUD Module
db = AnimalShelter(username, password, host, port, database, collection)

# class read method must support return of list object and accept projection json input
# sending the read method an empty document requests all documents be returned
df = pd.DataFrame.from_records(db.read({}))

# MongoDB v5+ is going to return the '_id' column and that is going to have an 
# invlaid object type of 'ObjectID' - which will cause the data_table to crash - so we remove
# it in the dataframe here. The df.drop command allows us to drop the column. If we do not set
# inplace=True - it will reeturn a new dataframe that does not contain the dropped column(s)
df.drop(columns=['_id'],inplace=True)

## Debug
# print(len(df.to_dict(orient='records')))
# print(df.columns)


#########################
# Dashboard Layout / View
#########################
app = dash.Dash(__name__)

#FIX ME Add in Grazioso Salvare’s logo
image_filename = 'Grazioso_Salvare_Logo.png'
with open(image_filename, "rb") as image_file:
    encoded_image = base64.b64encode(image_file.read()).decode('utf-8')

#FIX ME Place the HTML image tag in the line below into the app.layout code according to your design
#FIX ME Also remember to include a unique identifier such as your name or date
#html.Img(src='data:image/png;base64,{}'.format(encoded_image.decode()))

app.layout = html.Div([
# Add the company logo
    html.Div([
        html.Img(
            src='data:image/png;base64,{}'.format(encoded_image),
            style={'height': '250px', 'width': 'auto', 'margin': '10px'}
        )
    ], style={'textAlign': 'center'}),  # Center the logo
    
    html.Center(html.B(html.H1('Jordan Mitchell Dashboard'))),  # Dashboard title
    html.Hr(),
    html.Div(
        
#FIXME Add in code for the interactive filtering options. For example, Radio buttons, drop down, checkboxes, etc.
    # Convert rescue type options to a multichoice checklist for more flexible filtering
    html.Div([
    html.Label("Select one or more Rescue Types:"),
    dcc.Checklist(
        id='filter-type',  # ID used in callback
        options=[
            {'label': 'Water Rescue', 'value': 'Water Rescue'},
            {'label': 'Mountain Rescue', 'value': 'Mountain Rescue'},
            {'label': 'Disaster Rescue', 'value': 'Disaster Rescue'}
        ],
        value=[],  # No options selected by default
        labelStyle={'display': 'inline-block'}
    ),

    html.Br(),

    html.Label("Select one or more Outcome Types:"),
    dcc.Checklist(
        id='outcome-type',  # ID used in callback
        options=[
            {'label': 'Adoption', 'value': 'Adoption'},
            {'label': 'Transfer', 'value': 'Transfer'},
            {'label': 'Euthanasia', 'value': 'Euthanasia'},
            {'label': 'Return to Owner', 'value': 'Return to Owner'}
        ],
        value=[],  # No options selected by default
        labelStyle={'display': 'inline-block'}
    )
])

    ),
    html.Hr(),
    dash_table.DataTable(id='datatable-id',
                         columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
                         data=df.to_dict('records'),
#FIXME: Set up the features for your interactive data table to make it user-friendly for your client
#If you completed the Module Six Assignment, you can copy in the code you created here 
        editable=True,
        row_selectable="single",  # Allow selection of a single row
        selected_rows=[],
        filter_action="native",  # Enable filtering
        sort_action="native",  # Enable sorting
        page_action="native",  # Enable pagination
        page_current=0,  # Start on the first page
        page_size=10,  # Show 10 rows per page
                        ),
    html.Br(),
    html.Hr(),
#This sets up the dashboard so that your chart and your geolocation chart are side-by-side
    html.Div(className='row',
         style={'display' : 'flex'},
             children=[
        html.Div(
            id='graph-id',
            className='col s12 m6',

            ),
        html.Div(
            id='map-id',
            className='col s12 m6',
            )
        ])
])

#############################################
# Interaction Between Components / Controller
#############################################


# This callback updates the DataTable based on selected rescue types and outcome types.
# It uses MongoDB queries to filter the data accordingly.
@app.callback(
    Output('datatable-id', 'data'),
    [Input('filter-type', 'value'),  # List of selected rescue types
     Input('outcome-type', 'value')]  # List of selected outcome types
)
def update_dashboard(rescue_types, outcome_types):
    try:
        # Initialize query as empty. Default is to return all documents
        query = {}

        # Prepare list to hold rescue filters (if any)
        rescue_filters = []

        # Loop through selected rescue types and build corresponding MongoDB queries
        if 'All' not in rescue_types:
            if 'Water Rescue' in rescue_types:
                # Define filter for Water Rescue dogs
                rescue_filters.append({
                    "animal_type": "Dog",
                    "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
                    "breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]},
                    "sex_upon_outcome": "Intact Female"
                })
            if 'Mountain Rescue' in rescue_types:
                # Define filter for Mountain Rescue dogs
                rescue_filters.append({
                    "animal_type": "Dog",
                    "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
                    "breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]},
                    "sex_upon_outcome": "Intact Male"
                })
            if 'Disaster Rescue' in rescue_types:
                # Define filter for Disaster Rescue dogs
                rescue_filters.append({
                    "animal_type": "Dog",
                    "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
                    "breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]},
                    "sex_upon_outcome": "Intact Male"
                })
            # If any rescue filters are selected, use $or to include matches
            if rescue_filters:
                query["$or"] = rescue_filters

        # Handle Outcome Type filtering
        if 'All' not in outcome_types:
            # Add outcome filter with $in to match any of the selected outcomes
            query["outcome_type"] = {"$in": outcome_types}

        # Read from MongoDB using the combined query
        filtered_df = pd.DataFrame.from_records(db.read(query))

        # Drop the MongoDB internal ID field to avoid DataTable crashes
        filtered_df.drop(columns=['_id'], inplace=True, errors='ignore')

        # Return the filtered records to the DataTable component
        return filtered_df.to_dict('records')

    except Exception as e:
        print(f"Error: {e}")
        # Return an empty table if something goes wrong
        return pd.DataFrame().to_dict('records')

        
## FIX ME Add code to filter interactive data table with MongoDB queries
#
#        
#        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns]
#        data=df.to_dict('records')
#       
#       
#        return (data,columns)

# Callback to update the pie chart based on selected filters (rescue types)
@app.callback(
    Output('graph-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('filter-type', "value")])
def update_graphs(viewData, filter_type):
    if viewData is None or len(viewData) == 0:
        return [dcc.Graph(figure=px.pie(names=['No Data'], values=[1], title='No Data'))]

    df = pd.DataFrame.from_dict(viewData)

    if 'breed' not in df.columns or df['breed'].isnull().all():
        return [dcc.Graph(figure=px.pie(names=['No Data'], values=[1], title='No Breed Data'))]

    # Count how many unique breeds exist in the filtered view
    unique_breeds = df['breed'].nunique()

    # If there are too many breeds, group those <1% into 'Other' to simplify chart
    if unique_breeds > 15:
        breed_counts = df['breed'].value_counts()
        threshold = 0.01 * breed_counts.sum()

        grouped_breeds = breed_counts[breed_counts >= threshold].index

        df['breed_grouped'] = df['breed'].apply(lambda x: x if x in grouped_breeds else "Other (less than 1%)")

        pie_chart = px.pie(
            df,
            names='breed_grouped',
            title='Distribution of Breeds (Grouped for Clarity)'
        )
    else:
        pie_chart = px.pie(df, names='breed', title='Distribution of Breeds (Filtered)')

    pie_chart.update_layout(margin=dict(t=30, b=0, l=0, r=0))  # optional: cleaner spacing

    return [dcc.Graph(figure=pie_chart)]


    ###FIX ME ####
    # add code for chart of your choice (e.g. pie chart) #

    #return [
    #    dcc.Graph(            
    #        figure = px.pie(df, names='breed', title='Preferred Animals')
    #    )    
    #]
    
#This callback will highlight a cell on the data table when the user selects it
@app.callback(
    Output('datatable-id', 'style_data_conditional'),
    [Input('datatable-id', 'selected_columns')]
)
def update_styles(selected_columns):
    # Ensure selected_column is valid
    if not selected_columns:
        return []  # No styling applied when no column is selected
    
    return [{
        'if': {'column_id': i},
        'background_color': '#D2F3FF'
    } for i in selected_columns]

# This callback will update the geo-location chart for the selected data entry
# derived_virtual_data will be the set of data available from the datatable in the form of 
# a dictionary.
# derived_virtual_selected_rows will be the selected row(s) in the table in the form of
# a list. For this application, we are only permitting single row selection so there is only
# one value in the list.
# The iloc method allows for a row, column notation to pull data from the datatable
@app.callback(
    Output('map-id', "children"),
    [Input('datatable-id', "derived_virtual_data"),
     Input('datatable-id', "derived_virtual_selected_rows")])
def update_map(viewData, index):
#Code for geolocation chart
    # Convert table data to DataFrame
    df = pd.DataFrame.from_dict(viewData)
    # Austin TX is at [30.75,-97.48]
    # Verify if a row is selected
    if viewData is None or index is None or len(index) == 0:
        return dl.Map(style={'width': '1000px', 'height': '500px'}, center=[30.75, -97.48], zoom=10, children=[
            dl.TileLayer(id="base-layer-id"),
            dl.Marker(position=[30.75, -97.48], children=[
                dl.Tooltip("Austin Animal Center"),
                dl.Popup([
                    html.H4("Default Location: Austin Animal Center"),
                    html.P("Default location of the animal shelter")
                ])
            ])
        ])
    
    # Extract data from the selected row
    row = index[0]
    lat = float(viewData[row]['location_lat'])
    lon = float(viewData[row]['location_long'])
    name = viewData[row]['name']
    breed = viewData[row]['breed']
    
    # Return map with location marker
    return dl.Map(style={'width': '1000px', 'height': '500px'}, center=[lat, lon], zoom=15, children=[
        dl.TileLayer(id="base-layer-id"),
        dl.Marker(position=[lat, lon], children=[
            dl.Tooltip(name),
            dl.Popup([
                html.H4("Animal Name"),
                html.P(name),
                html.P(breed)
            ])
        ])
    ])
if __name__ == '__main__':
    app.run(debug=True)

# %%



