package com.example.cs360project2weighttracker_jordanmitchell;

// This class manages the local SQLite database for storing user weight entries.
// It includes methods to create the database, insert, update, retrieve, and delete records.

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class WeightDatabaseHelper extends SQLiteOpenHelper {

    // Database Name + Version
    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // Table Name
    private static final String TABLE_WEIGHTS = "weights";

    // Column Names
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    // SQL statement to create the weights table
    private static final String CREATE_TABLE_WEIGHTS =
            "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_DATE + " TEXT NOT NULL, " +
                    COLUMN_WEIGHT + " REAL NOT NULL);";

    // Constructor
    public WeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create the weights table when the database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_WEIGHTS);
    }

    // Drop and recreate the table if the schema version is updated
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // CRUD for database

    // Inserts a new weight entry with the specified date and weight
    public boolean insertWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date); // Set the date column
        values.put(COLUMN_WEIGHT, weight); // Set the weight column

        long result = db.insert(TABLE_WEIGHTS, null, values); // Attempt to insert row
        db.close();
        return result != -1; // Returns true if insertion is successful
    }

    // Retrieves all weight entries from the database
    // Results are ordered by date descending
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTS + " ORDER BY " + COLUMN_DATE + " DESC", null);
    }

    // Updates the weight value for a specific entry based on its ID
    // Returns true if at least one row was updated
    public boolean updateWeight(int id, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, newWeight); // New weight value

        int rowsUpdated = db.update(TABLE_WEIGHTS, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsUpdated > 0;
    }

    // Deletes a weight entry from the database based on its ID
    // Returns true if a row was deleted
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(TABLE_WEIGHTS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return rowsDeleted > 0;
    }
}
