package com.example.cs360project2weighttracker_jordanmitchell;

// This activity allows users to configure their SMS notification preferences
// Users can toggle reminders for daily logs, goals, and achievements

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NotificationPreferencesActivity extends AppCompatActivity {

    private CheckBox checkBoxDailyReminders, checkBoxGoalReminders, checkBoxAchievements;
    private Button buttonSavePreferences, buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_preferences);

        // Initialize checkbox and button UI elements
        checkBoxDailyReminders = findViewById(R.id.checkBoxDailyReminders);
        checkBoxGoalReminders = findViewById(R.id.checkBoxGoalReminders);
        checkBoxAchievements = findViewById(R.id.checkBoxAchievements);
        buttonSavePreferences = findViewById(R.id.buttonSavePreferences);
        buttonBack = findViewById(R.id.buttonBack);

        // Handle Save Preferences button click
        buttonSavePreferences.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNotificationPreferences();
            }
        });

        // Handle Back button click
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Close the activity and return
            }
        });
    }

    // Builds a summary of the user's selected notification options
    // Displays it as a Toast message
    private void saveNotificationPreferences() {
        StringBuilder preferences = new StringBuilder("SMS notifications enabled for: ");

        if (checkBoxDailyReminders.isChecked()) {
            preferences.append("\n- Daily Reminders");
        }
        if (checkBoxGoalReminders.isChecked()) {
            preferences.append("\n- Goal Reminders");
        }
        if (checkBoxAchievements.isChecked()) {
            preferences.append("\n- Achievement Notifications");
        }

        if (!checkBoxDailyReminders.isChecked() && !checkBoxGoalReminders.isChecked() && !checkBoxAchievements.isChecked()) {
            preferences = new StringBuilder("No notifications enabled.");
        }

        // Display confirmation
        Toast.makeText(this, preferences.toString(), Toast.LENGTH_LONG).show();
    }
}
