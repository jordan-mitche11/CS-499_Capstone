package com.example.cs360project2weighttracker_jordanmitchell;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.SharedPreferences; // Needed for saving user goal persistently

public class SetGoalsActivity extends AppCompatActivity {

    // UI references for input fields and goal display
    private EditText editTextCurrentWeight, editTextWeightGoal, editTextTargetDate;
    private TextView textGoalSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_goals);

        // Adjust layout to respect system window insets (ex. status bar, navigation)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });

        // Initialize UI components
        editTextCurrentWeight = findViewById(R.id.editTextCurrentWeight);
        editTextWeightGoal = findViewById(R.id.editTextWeightGoal);
        editTextTargetDate = findViewById(R.id.editTextTargetDate);
        textGoalSummary = findViewById(R.id.textGoalSummary);

        // Load saved goal data from SharedPreferences (if available)
        SharedPreferences prefs = getSharedPreferences("GoalPrefs", MODE_PRIVATE);
        String savedGoalWeight = prefs.getString("goalWeight", null);
        String savedTargetDate = prefs.getString("targetDate", null);
        if (savedGoalWeight != null && savedTargetDate != null) {
            String savedGoalSummary = "Your current goal is to reach " + savedGoalWeight + " lbs by " + savedTargetDate;
            textGoalSummary.setText(savedGoalSummary);
        }

        Button buttonSubmitGoal = findViewById(R.id.buttonSubmitGoal);
        Button buttonBack = findViewById(R.id.buttonBack);

        // Handle "Save Goal" button click
        buttonSubmitGoal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveGoal();
            }
        });

        // Handle "Back" button click (When user clicks "Back", close the activity and return to previous screen)
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close activity and return
                finish();
            }
        });
    }

    // Save the user's goal weight and target date
    private void saveGoal() {
        String currentWeight = editTextCurrentWeight.getText().toString().trim();
        String goalWeight = editTextWeightGoal.getText().toString().trim();
        String targetDate = editTextTargetDate.getText().toString().trim();

        // Ensure all fields are populated. Display error if any field is left empty
        if (currentWeight.isEmpty() || goalWeight.isEmpty() || targetDate.isEmpty()) {
            textGoalSummary.setText("Please enter all fields to set a goal.");
            return;
        }

        // Update Goal display TextView. Show the entered goal in summary text
        String goalSummary = "Your current goal is to reach " + goalWeight + " lbs by " + targetDate;
        textGoalSummary.setText(goalSummary);

        // Save goal data persistently to SharedPreferences
        SharedPreferences prefs = getSharedPreferences("GoalPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("goalWeight", goalWeight);
        editor.putString("targetDate", targetDate);
        editor.apply();

    }
}
