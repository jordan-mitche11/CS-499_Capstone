package com.example.cs360project2weighttracker_jordanmitchell;

// This activity allows users to log their weight for the current day
// The entry is saved to the local SQLite database with the current date

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LogWeightActivity extends AppCompatActivity {

    private EditText editTextWeight;
    private WeightDatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_weight);

        // Initialize UI components
        editTextWeight = findViewById(R.id.editTextWeight);
        Button buttonSaveWeight = findViewById(R.id.buttonSaveWeight);
        Button buttonBack = findViewById(R.id.buttonBack); // Find Back Button

        // Set up the database helper
        databaseHelper = new WeightDatabaseHelper(this);

        // Listen for Save Weight button. When Save button is clicked, log the weight
        buttonSaveWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveWeight();
            }
        });

        // Listen for Back Button press. When Back button is clicked, return to previous screen
        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Close activity and return to previous
                finish();
            }
        });
    }

    // Logs the user's weight into the database with the current date
    private void saveWeight() {
        String weightStr = editTextWeight.getText().toString();

        if (weightStr.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse the weight and get the current date
        double weight = Double.parseDouble(weightStr);
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        // Insert the record and show appropriate message
        boolean success = databaseHelper.insertWeight(currentDate, weight);

        if (success) {
            Toast.makeText(this, "Weight logged successfully", Toast.LENGTH_SHORT).show();
            editTextWeight.setText(""); // Clear input field
        } else {
            Toast.makeText(this, "Failed to log weight", Toast.LENGTH_SHORT).show();
        }
    }
}
