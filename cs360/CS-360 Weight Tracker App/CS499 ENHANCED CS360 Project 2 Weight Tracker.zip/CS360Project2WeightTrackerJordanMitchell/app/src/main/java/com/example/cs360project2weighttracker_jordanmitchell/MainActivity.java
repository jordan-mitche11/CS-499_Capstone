package com.example.cs360project2weighttracker_jordanmitchell;

// Main entry point after login
// Provides navigation to major app features

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Declare UI buttons
    private Button buttonLogWeight, buttonViewHistory, buttonGoals, buttonNotifications, buttonLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Handle safe padding for device notches/status bar
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize buttons
        buttonLogWeight = findViewById(R.id.buttonLogWeight);
        buttonViewHistory = findViewById(R.id.buttonViewHistory);
        buttonGoals = findViewById(R.id.buttonGoals);
        buttonNotifications = findViewById(R.id.buttonNotifications);
        buttonLogout = findViewById(R.id.buttonLogout);

        // Set onClickListeners for screen navigation.
        // Navigate to LogWeightActivity
        buttonLogWeight.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LogWeightActivity.class);
            startActivity(intent);
        });

        // Navigate to DataDisplayActivity to view weight history
        buttonViewHistory.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });

        // Navigate to SetGoalsActivity for setting/viewing weight goals
        buttonGoals.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SetGoalsActivity.class);
            startActivity(intent);
        });

        // Navigate to SMSPermissionsActivity to configure SMS settings
        buttonNotifications.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SMSPermissionsActivity.class);
            startActivity(intent);
        });

        // Log out and return to LoginActivity, clearing activity back stack
        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear back stack
            startActivity(intent);
            // Close MainActivity
            finish();
        });
    }
}
